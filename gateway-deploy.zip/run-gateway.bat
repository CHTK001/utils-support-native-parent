@echo off
REM ============================================================
REM  Gateway Server startup script (Windows)
REM ============================================================
REM  Starts HTTP server (8090) + WebSocket bridge (8182)
REM  Logs output to server.log
REM ============================================================

setlocal

set JAVA_HOME=C:\Program Files\Amazon Corretto\jdk25.0.3_9
set JAVA_EXE=%JAVA_HOME%\bin\java.exe

if not exist "%JAVA_EXE%" (
    echo [ERROR] Java not found: %JAVA_EXE%
    echo Please set JAVA_HOME to point to JDK 25+
    exit /b 1
)

set BASE_DIR=%~dp0
set ARGFILE=%BASE_DIR%gateway.argfile

if not exist "%ARGFILE%" (
    echo [ERROR] argfile missing: %ARGFILE%
    echo Please generate cp.txt and gateway.argfile first
    exit /b 1
)

echo [START] Gateway Server starting...
echo [INFO] Java: %JAVA_EXE%
echo [INFO] Argfile: %ARGFILE%
echo [INFO] Log: %BASE_DIR%server.log
echo.

"%JAVA_EXE%" @"%ARGFILE%" > "%BASE_DIR%server.log" 2>&1

echo [STOP] Gateway Server exited, code=%ERRORLEVEL%
endlocal
